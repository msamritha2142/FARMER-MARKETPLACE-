# Farmer Marketplace (MERN)

Connects farmers and customers. Farmers list products with quantity, price and location; customers browse and search.

## Objectives
- Demonstrate MERN stack development
- CRUD operations using MongoDB
- REST APIs with Node.js and Express.js
- Frontend with React.js
- Authentication and role-based access (farmer / customer)

## Tech stack
MongoDB (Atlas), Express.js, React (Vite), Node.js, JWT, bcrypt

## Run
Server:
    cd server
    npm install
    cp .env.example .env     (then fill in MONGO_URI and JWT_SECRET)
    npm start

Client (second terminal):
    cd client
    npm install
    npm run dev

Open http://localhost:5173

## API
| Method | Route | Access |
|---|---|---|
| POST | /api/auth/register | public |
| POST | /api/auth/login | public |
| GET | /api/products?q=&location=&category= | public |
| GET | /api/products/mine | farmer |
| POST | /api/products | farmer |
| PUT | /api/products/:id | farmer (owner) |
| DELETE | /api/products/:id | farmer (owner) |
