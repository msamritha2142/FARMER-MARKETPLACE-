import { useEffect, useState } from 'react';
import { api } from '../api.js';
import ProductCard from '../components/ProductCard.jsx';

export const CATEGORIES = ['Vegetables', 'Fruits', 'Grains', 'Dairy', 'Other'];

export default function Marketplace() {
  const [products, setProducts] = useState([]);
  const [q, setQ] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const params = new URLSearchParams({ q, location, category }).toString();
    api('/products?' + params)
      .then((d) => { setProducts(d); setError(''); })
      .catch(() => setError('Could not load products. Is the server running?'));
  }, [q, location, category]);

  return (
    <>
      <h1>Fresh from the farm</h1>
      <div className="filters">
        <input placeholder="Search product..." value={q} onChange={(e) => setQ(e.target.value)} />
        <input placeholder="Location..." value={location} onChange={(e) => setLocation(e.target.value)} />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All categories</option>
          {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      {error && <p className="error">{error}</p>}
      {!error && products.length === 0 && <p className="muted">No products found. Farmers can add products after signing up.</p>}
      <div className="grid">{products.map((p) => <ProductCard key={p._id} p={p} />)}</div>
    </>
  );
}
