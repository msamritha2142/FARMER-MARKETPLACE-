import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';

export default function Login() {
  const [f, setF] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const { login } = useAuth();
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const d = await api('/auth/login', { method: 'POST', body: f });
      login(d);
      nav(d.user.role === 'farmer' ? '/dashboard' : '/');
    } catch (err) { setError(err.message); }
  };

  return (
    <form className="panel" onSubmit={submit}>
      <h2>Log in</h2>
      {error && <p className="error">{error}</p>}
      <input type="email" placeholder="Email" required onChange={(e) => setF({ ...f, email: e.target.value })} />
      <input type="password" placeholder="Password" required onChange={(e) => setF({ ...f, password: e.target.value })} />
      <button className="btn">Log in</button>
    </form>
  );
}
