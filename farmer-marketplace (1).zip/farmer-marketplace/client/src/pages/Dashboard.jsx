import { useEffect, useState } from 'react';
import { api } from '../api.js';
import ProductCard from '../components/ProductCard.jsx';
import { CATEGORIES } from './Marketplace.jsx';

const empty = { name: '', category: 'Vegetables', quantity: '', price: '', location: '' };

export default function Dashboard() {
  const [items, setItems] = useState([]);
  const [f, setF] = useState(empty);
  const [editId, setEditId] = useState(null);
  const [error, setError] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const load = () => api('/products/mine').then(setItems).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const body = { ...f, quantity: Number(f.quantity), price: Number(f.price) };
      await api(editId ? `/products/${editId}` : '/products', { method: editId ? 'PUT' : 'POST', body });
      setF(empty); setEditId(null); setError(''); load();
    } catch (err) { setError(err.message); }
  };

  const edit = (p) => {
    setEditId(p._id);
    setF({ name: p.name, category: p.category, quantity: p.quantity, price: p.price, location: p.location });
    window.scrollTo(0, 0);
  };

  const remove = async (id) => {
    if (confirm('Delete this product?')) { await api(`/products/${id}`, { method: 'DELETE' }); load(); }
  };

  return (
    <>
      <h1>My products</h1>
      <form className="panel wide" onSubmit={submit}>
        <h2>{editId ? 'Update product' : 'Add a product'}</h2>
        {error && <p className="error">{error}</p>}
        <input placeholder="Product name" required value={f.name} onChange={set('name')} />
        <select value={f.category} onChange={set('category')}>
          {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <input type="number" placeholder="Quantity (kg)" required min="0" value={f.quantity} onChange={set('quantity')} />
        <input type="number" placeholder="Price per kg (₹)" required min="0" value={f.price} onChange={set('price')} />
        <input placeholder="Location" required value={f.location} onChange={set('location')} />
        <div className="row">
          <button className="btn">{editId ? 'Save changes' : 'Add product'}</button>
          {editId && <button type="button" className="btn light dark" onClick={() => { setEditId(null); setF(empty); }}>Cancel</button>}
        </div>
      </form>
      <div className="grid">{items.map((p) => <ProductCard key={p._id} p={p} onEdit={edit} onDelete={remove} />)}</div>
      {items.length === 0 && <p className="muted">You have not added any products yet.</p>}
    </>
  );
}
