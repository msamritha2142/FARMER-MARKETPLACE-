import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';

export default function Register() {
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'customer', location: '' });
  const [error, setError] = useState('');
  const { login } = useAuth();
  const nav = useNavigate();
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    try {
      const d = await api('/auth/register', { method: 'POST', body: f });
      login(d);
      nav(d.user.role === 'farmer' ? '/dashboard' : '/');
    } catch (err) { setError(err.message); }
  };

  return (
    <form className="panel" onSubmit={submit}>
      <h2>Create account</h2>
      {error && <p className="error">{error}</p>}
      <input placeholder="Full name" required onChange={set('name')} />
      <input type="email" placeholder="Email" required onChange={set('email')} />
      <input type="password" placeholder="Password" required minLength={6} onChange={set('password')} />
      <input placeholder="Your location" onChange={set('location')} />
      <select value={f.role} onChange={set('role')}>
        <option value="customer">I want to buy (customer)</option>
        <option value="farmer">I want to sell (farmer)</option>
      </select>
      <button className="btn">Sign up</button>
    </form>
  );
}
