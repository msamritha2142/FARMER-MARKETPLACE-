import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Marketplace from './pages/Marketplace.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import { useAuth } from './AuthContext.jsx';

export default function App() {
  const { user } = useAuth();
  return (
    <>
      <Navbar />
      <main className="wrap">
        <Routes>
          <Route path="/" element={<Marketplace />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={user?.role === 'farmer' ? <Dashboard /> : <Navigate to="/login" />} />
        </Routes>
      </main>
    </>
  );
}
