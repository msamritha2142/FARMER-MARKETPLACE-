import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  return (
    <header className="nav">
      <Link to="/" className="brand">Farmer Marketplace</Link>
      <nav>
        <Link to="/">Browse</Link>
        {user?.role === 'farmer' && <Link to="/dashboard">My products</Link>}
        {user ? (
          <>
            <span className="hello">Hi, {user.name}</span>
            <button className="btn light" onClick={() => { logout(); nav('/'); }}>Log out</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register" className="btn light">Sign up</Link>
          </>
        )}
      </nav>
    </header>
  );
}
