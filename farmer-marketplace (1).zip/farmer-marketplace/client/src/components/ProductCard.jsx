export default function ProductCard({ p, onEdit, onDelete }) {
  return (
    <article className="card">
      <span className="tag">{p.category}</span>
      <h3>{p.name}</h3>
      <p className="price">₹{p.price} <small>per kg</small></p>
      <p>{p.quantity} kg available</p>
      <p>{p.location}</p>
      {p.farmer?.name && <p className="muted">Sold by {p.farmer.name}</p>}
      {onEdit && (
        <div className="row">
          <button className="btn small" onClick={() => onEdit(p)}>Edit</button>
          <button className="btn small danger" onClick={() => onDelete(p._id)}>Delete</button>
        </div>
      )}
    </article>
  );
}
