const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const sign = (u) => jwt.sign({ id: u._id, role: u.role, name: u.name }, process.env.JWT_SECRET, { expiresIn: '7d' });
const out = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, location: u.location });

router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, location } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required' });
    if (await User.findOne({ email: email.toLowerCase() })) return res.status(400).json({ message: 'Email already registered' });
    const user = await User.create({ name, email, location, role: role === 'farmer' ? 'farmer' : 'customer', password: await bcrypt.hash(password, 10) });
    res.status(201).json({ token: sign(user), user: out(user) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/login', async (req, res) => {
  try {
    const user = await User.findOne({ email: (req.body.email || '').toLowerCase() });
    if (!user || !(await bcrypt.compare(req.body.password || '', user.password)))
      return res.status(400).json({ message: 'Wrong email or password' });
    res.json({ token: sign(user), user: out(user) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
