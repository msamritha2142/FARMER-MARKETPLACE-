const router = require('express').Router();
const Product = require('../models/Product');
const { protect, farmerOnly } = require('../middleware/auth');

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// View all (search / location / category filters)
router.get('/', async (req, res) => {
  try {
    const { q, location, category } = req.query;
    const f = {};
    if (q) f.name = new RegExp(esc(q), 'i');
    if (location) f.location = new RegExp(esc(location), 'i');
    if (category) f.category = category;
    res.json(await Product.find(f).populate('farmer', 'name').sort('-createdAt'));
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Farmer's own products
router.get('/mine', protect, farmerOnly, async (req, res) => {
  res.json(await Product.find({ farmer: req.user.id }).sort('-createdAt'));
});

// Add
router.post('/', protect, farmerOnly, async (req, res) => {
  try { res.status(201).json(await Product.create({ ...req.body, farmer: req.user.id })); }
  catch (e) { res.status(400).json({ message: e.message }); }
});

// Update
router.put('/:id', protect, farmerOnly, async (req, res) => {
  try {
    const p = await Product.findOneAndUpdate({ _id: req.params.id, farmer: req.user.id }, req.body, { new: true, runValidators: true });
    p ? res.json(p) : res.status(404).json({ message: 'Product not found' });
  } catch (e) { res.status(400).json({ message: e.message }); }
});

// Delete
router.delete('/:id', protect, farmerOnly, async (req, res) => {
  const p = await Product.findOneAndDelete({ _id: req.params.id, farmer: req.user.id });
  p ? res.json({ message: 'Deleted' }) : res.status(404).json({ message: 'Product not found' });
});

module.exports = router;
