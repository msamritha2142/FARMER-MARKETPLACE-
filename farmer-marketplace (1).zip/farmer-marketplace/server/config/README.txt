Database connection is in server.js (MONGO_URI from .env).
