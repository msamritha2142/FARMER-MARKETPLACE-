const jwt = require('jsonwebtoken');
exports.protect = (req, res, next) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Please log in' });
  try { req.user = jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch { res.status(401).json({ message: 'Session expired, log in again' }); }
};
exports.farmerOnly = (req, res, next) =>
  req.user.role === 'farmer' ? next() : res.status(403).json({ message: 'Farmers only' });
